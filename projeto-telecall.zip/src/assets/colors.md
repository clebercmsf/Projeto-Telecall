# Colors
* red1: #CA1C2A
* red2: #8a131d
* red2: #4A0A10
* white1: #E0E0E0
* white2: #f0ffffde
* white3: #e6e6e6
* blue1: #0E4E7C
* blue2: #082F4A
* blue2: #003b71
* blue3: #5398C9
* blue4: #95B9D2
* gray1: #31353B
* gray2: #87898d