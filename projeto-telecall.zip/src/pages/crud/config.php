<?php
  $dbHost = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbName = "db_telecall";
    
  $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
?>